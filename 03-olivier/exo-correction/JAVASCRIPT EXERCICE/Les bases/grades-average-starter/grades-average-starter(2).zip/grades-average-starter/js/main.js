'use strict';   // Mode strict du JavaScript

// Soit la classe suivante
const students = [
    {
        firstname: 'Claire',
        lastname: 'Jollet',
        birhtDate: '2005-05-12',
        grades: [14,15,14,14,16,12]
    },
    {
        firstname: 'Léo',
        lastname: 'Chapelier',
        birhtDate: '2004-05-12',
        grades: [10,11,9,10,12,8]
    },
    {
        firstname: 'Oscar',
        lastname: 'Wilde',
        birhtDate: '1854-09-16',
        grades: [18,17,20,18,19,17]
    },
];