# Moyenne des notes
## objectif
A partir d'un tableau d'objets d'élèves, calculer la moyenne des notes de chaque élève, et la stocker dans une nouvelle propriété 'average'.

On souhaite ensuite afficher la moyenne de chaque élève avec son nom et son prénom. 

## Remarque
Les moyennes doivent être arrondies à 2 chiffres après la virgule